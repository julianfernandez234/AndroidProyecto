package com.example.splash_nata;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class BotonesApp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_botones_app);
    }
}